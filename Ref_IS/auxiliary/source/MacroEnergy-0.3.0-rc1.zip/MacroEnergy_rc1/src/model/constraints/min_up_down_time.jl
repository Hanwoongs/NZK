Base.@kwdef mutable struct MinUpTimeConstraint <: OperationConstraint
    value::Union{Missing,Vector{Float64}} = missing
    constraint_dual::Union{Missing,Vector{Float64}} = missing
    constraint_ref::Union{Missing,JuMPConstraint} = missing
end

Base.@kwdef mutable struct MinDownTimeConstraint <: OperationConstraint
    value::Union{Missing,Vector{Float64}} = missing
    constraint_dual::Union{Missing,Vector{Float64}} = missing
    constraint_ref::Union{Missing,JuMPConstraint} = missing
end

@doc raw"""
    add_model_constraint!(ct::MinDownTimeConstraint, e::EdgeWithUC, model::Model)

Add a min down time constraint to the edge `e` with unit commitment. The functional form of the constraint is:

```math
\begin{aligned}
    \frac{\text{capacity(e)}}{\text{capacity\_size(e)}} - \text{ucommit(e, t)} \geq \sum_{h=0}^{\text{min\_down\_time(e)}-1} \text{ushut(e, t-h)}
\end{aligned}
```
for each time `t` in `time_interval(e)` for the edge `e`. The function [`timestepbefore`](@ref) is used to perform the time wrapping within the subperiods and get the correct time step before `t`.

!!! note "Min down time duration"
    This constraint will throw an error if the minimum down time is longer than the length of one subperiod.
"""
function add_model_constraint!(ct::MinDownTimeConstraint, e::EdgeWithUC, model::Model)
    if !has_capacity(e)
        @warn "Min down time constraints are only available for edges with capacity"
        return
    end

    ti = time_interval(e)
    sps = subperiods(e)
    if min_down_time(e) > minimum(length.(sps))
        error(
            "The minimum down time for $(id(e)) is longer than the length of one subperiod",
        )
    else
        if has_capacity(e)
            ct.constraint_ref = @constraint(
                model,
                [t in ti],
                capacity(e) / capacity_size(e) - ucommit(e, t) >= sum(
                    ushut(e, timestepbefore(t, h, sps))
                    for h = 0:min_down_time(e)-1;
                    init = 0,
                ),
            )
        end
    end

    return nothing
end

@doc raw"""
    add_model_constraint!(ct::MinUpTimeConstraint, e::EdgeWithUC, model::Model)

Add a min up time constraint to the edge `e` with unit commitment. The functional form of the constraint is:

```math
\begin{aligned}
    \text{ucommit(e, t)} \geq \sum_{h=0}^{\text{min\_up\_time(e)}-1} \text{ustart(e, t-h)}
\end{aligned}
```
for each time `t` in `time_interval(e)` for the edge `e`. The function [`timestepbefore`](@ref) is used to perform the time wrapping within the subperiods and get the correct time step before `t`.

!!! note "Min up time duration"
    This constraint will throw an error if the minimum up time is longer than the length of one subperiod.
"""
function add_model_constraint!(ct::MinUpTimeConstraint, e::EdgeWithUC, model::Model)
    if !has_capacity(e)
        @warn "Min up time constraints are only available for edges with capacity"
        return
    end

    ti = time_interval(e)
    sps = subperiods(e)
    if min_up_time(e) > minimum(length.(sps))
        error("The minimum up time for $(id(e)) is longer than the length of one subperiod")
    else
        if has_capacity(e)
            ct.constraint_ref = @constraint(
                model,
                [t in ti],
                ucommit(e, t) >= sum(
                    ustart(e, timestepbefore(t, h, sps))
                    for h = 0:min_up_time(e)-1;
                    init = 0,
                )
            )
        end
    end

    return nothing
end
